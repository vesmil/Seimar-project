// SPDX-License-Identifier: GPL-2.0
/*
 * Xilinx Test Pattern Generator
 *
 * Copyright (C) 2013-2015 Ideas on Board
 * Copyright (C) 2013-2015 Xilinx, Inc.
 *
 * Contacts: Hyun Kwon <hyun.kwon@xilinx.com>
 *           Laurent Pinchart <laurent.pinchart@ideasonboard.com>
 */

#include <linux/device.h>
#include <linux/gpio/consumer.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/xilinx-v4l2-controls.h>

#include <media/v4l2-async.h>
#include <media/v4l2-subdev.h>

/* #include "xilinx-hls-common.h" */
#include "xilinx-vip.h"


#define XTPG_CTRL_STATUS_SLAVE_ERROR		(1 << 16)
#define XTPG_CTRL_IRQ_SLAVE_ERROR		(1 << 16)

#define XTPG_MIN_WIDTH			(64)
#define XTPG_MIN_HEIGHT			(64)
#define XTPG_MAX_WIDTH			(10328)
#define XTPG_MAX_HEIGHT			(7760)

#define XTPG_MIN_PPC			1

#define XTPG_MIN_FRM_INT		1

/**
 * struct xtpg_device - Xilinx Test Pattern Generator device structure
 * @xvip: Xilinx Video IP device
 * @pad: media pad
 * @format: active V4L2 media bus format
 * @vip_format: format information corresponding to the active format
 * @streaming: is the video stream active
 * @width: Maximum width supported by this instance
 * @height: Maximum height supported by this instance
 * @fi_d: frame interval denominator
 * @fi_n: frame interval numerator
 * @ppc: Pixels per clock control
 */
struct xtpg_device {
	struct xvip_device xvip;
	struct media_pad pad;
	struct v4l2_mbus_framefmt format;
	const struct xvip_video_format *vip_format;
	bool streaming;

	u32 width;
	u32 height;
	u32 fi_d;
	u32 fi_n;
	u32 ppc;
};

static inline struct xtpg_device *to_tpg(struct v4l2_subdev *subdev)
{
	return container_of(subdev, struct xtpg_device, xvip.subdev);
}

/* -----------------------------------------------------------------------------
 * V4L2 Subdevice Video Operations
 */

static int xtpg_g_frame_interval(struct v4l2_subdev *subdev,
				 struct v4l2_subdev_frame_interval *fi)
{
	struct xtpg_device *xtpg = to_tpg(subdev);

	fi->interval.numerator = xtpg->fi_n;
	fi->interval.denominator = xtpg->fi_d;

	return 0;
}

static int xtpg_s_stream(struct v4l2_subdev *subdev, int enable)
{
	struct xtpg_device *xtpg = to_tpg(subdev);
	if (!enable)
		xtpg->streaming = false;
	else
		xtpg->streaming = true;
	return 0;
}

/* -----------------------------------------------------------------------------
 * V4L2 Subdevice Pad Operations
 */

static int xtpg_get_format(struct v4l2_subdev *subdev,
			   struct v4l2_subdev_pad_config *cfg,
			   struct v4l2_subdev_format *fmt)
{
	struct xtpg_device *xtpg = to_tpg(subdev);
	fmt->format = xtpg->format;
	return 0;
}

static int xtpg_enum_frame_size(struct v4l2_subdev *subdev,
			        struct v4l2_subdev_pad_config *cfg,
				struct v4l2_subdev_frame_size_enum *fse)
{
	struct v4l2_mbus_framefmt *format;
	/* struct xtpg_device *xtpg = to_tpg(subdev); */

	format = v4l2_subdev_get_try_format(subdev, cfg, fse->pad);

	if (fse->index || fse->code != format->code)
		return -EINVAL;

	fse->min_width = format->width;
	fse->max_width = format->width;
	fse->min_height = format->height;
	fse->max_height = format->height;

	return 0;
}

/* -----------------------------------------------------------------------------
 * V4L2 Subdevice Operations
 */

static int xtpg_open(struct v4l2_subdev *subdev, struct v4l2_subdev_fh *fh)
{
	struct xtpg_device *xtpg = to_tpg(subdev);
	struct v4l2_mbus_framefmt *format;

	format = v4l2_subdev_get_try_format(subdev, fh->pad, 0);
	*format = xtpg->format;

	return 0;
}

static int xtpg_close(struct v4l2_subdev *subdev, struct v4l2_subdev_fh *fh)
{
	return 0;
}

static const struct v4l2_subdev_core_ops xtpg_core_ops = {
};

static const struct v4l2_subdev_video_ops xtpg_video_ops = {
	.g_frame_interval = xtpg_g_frame_interval,
	.s_stream = xtpg_s_stream,
};

static const struct v4l2_subdev_pad_ops xtpg_pad_ops = {
	.enum_mbus_code		= xvip_enum_mbus_code,
	.enum_frame_size	= xtpg_enum_frame_size,
	.get_fmt		= xtpg_get_format,
};

static const struct v4l2_subdev_ops xtpg_ops = {
	.core   = &xtpg_core_ops,
	.video  = &xtpg_video_ops,
	.pad    = &xtpg_pad_ops,
};

static const struct v4l2_subdev_internal_ops xtpg_internal_ops = {
	.open	= xtpg_open,
	.close	= xtpg_close,
};

/* -----------------------------------------------------------------------------
 * Media Operations
 */

static const struct media_entity_operations xtpg_media_ops = {
	.link_validate = v4l2_subdev_link_validate,
};

/* -----------------------------------------------------------------------------
 * Platform Device Driver
 */

static int xtpg_parse_of(struct xtpg_device *xtpg)
{
	struct device *dev = xtpg->xvip.dev;
	struct device_node *node = xtpg->xvip.dev->of_node;
	struct device_node *ports;
	struct device_node *port;
	unsigned int nports = 0;
	bool has_endpoint = false;
	int ret;

	ret = of_property_read_u32(node, "wsl,height", &xtpg->height);
	if (ret < 0) {
		dev_err(dev, "wsl,height dt property is missing!");
		return -EINVAL;
	} else if (xtpg->height != 768) {
		dev_err(dev, "Invalid height in dt");
		return -EINVAL;
	}

	ret = of_property_read_u32(node, "wsl,width", &xtpg->width);
	if (ret < 0) {
		dev_err(dev, "wsl,width dt property is missing!");
		return -EINVAL;
	} else if (xtpg->width != 1024) {
		dev_err(dev, "Invalid width in dt");
		return -EINVAL;
	}

	ret = of_property_read_u32(node, "wsl,pixels-per-clock", &xtpg->ppc);
	if (ret < 0) {
		xtpg->ppc = XTPG_MIN_PPC;
		dev_dbg(dev, "failed to read wsl,pixels-per-clock in dt\n");
	} else if ((xtpg->ppc != 1) && (xtpg->ppc != 2) &&
			(xtpg->ppc != 4) && (xtpg->ppc != 8)) {
		dev_err(dev, "Invalid ppc config in dt\n");
		return -EINVAL;
	}

	ports = of_get_child_by_name(node, "ports");
	if (ports == NULL)
		ports = node;

	for_each_child_of_node(ports, port) {
		const struct xvip_video_format *format;
		struct device_node *endpoint;

		if (!of_node_name_eq(port, "port"))
			continue;

		format = xvip_of_get_format(port);
		if (IS_ERR(format)) {
			dev_err(dev, "invalid format in DT");
			of_node_put(port);
			return PTR_ERR(format);
		}

		/* Get and check the format description */
		if (!xtpg->vip_format) {
			xtpg->vip_format = format;
		} else if (xtpg->vip_format != format) {
			dev_err(dev, "in/out format mismatch in DT");
			of_node_put(port);
			return -EINVAL;
		}

		if (nports == 0) {
			endpoint = of_get_next_child(port, NULL);
			if (endpoint)
				has_endpoint = true;
			of_node_put(endpoint);
		}

		/* Count the number of ports. */
		nports++;
	}

	if (nports != 1) {
		dev_err(dev, "invalid number of ports %u\n", nports);
		return -EINVAL;
	}

	return 0;
}

static int xtpg_probe(struct platform_device *pdev)
{
	struct v4l2_subdev *subdev;
	struct xtpg_device *xtpg;
	int ret;

	xtpg = devm_kzalloc(&pdev->dev, sizeof(*xtpg), GFP_KERNEL);
	if (!xtpg)
		return -ENOMEM;

	xtpg->xvip.dev = &pdev->dev;

	ret = xtpg_parse_of(xtpg);
	if (ret < 0)
		return ret;

	/* Initialize V4L2 subdevice and media entity. */
	xtpg->pad.flags = MEDIA_PAD_FL_SOURCE;

	/* Initialize the default format */
	xtpg->format.code = xtpg->vip_format->code;
	xtpg->format.field = V4L2_FIELD_NONE;
	xtpg->format.colorspace = V4L2_COLORSPACE_RAW;

	xtpg->format.width = xtpg->width;
	xtpg->format.height = xtpg->height;

	/* Initialize V4L2 subdevice and media entity */
	subdev = &xtpg->xvip.subdev;
	v4l2_subdev_init(subdev, &xtpg_ops);
	subdev->dev = &pdev->dev;
	subdev->internal_ops = &xtpg_internal_ops;
	strscpy(subdev->name, dev_name(&pdev->dev), sizeof(subdev->name));
	v4l2_set_subdevdata(subdev, xtpg);
	subdev->flags |= V4L2_SUBDEV_FL_HAS_DEVNODE;
	subdev->entity.ops = &xtpg_media_ops;

	ret = media_entity_pads_init(&subdev->entity, 1, &xtpg->pad);
	if (ret < 0)
		goto error;

	platform_set_drvdata(pdev, xtpg);

	/* Initialize default frame interval */
	xtpg->fi_n = 1;
	xtpg->fi_d = 60;

	ret = v4l2_async_register_subdev(subdev);
	if (ret < 0) {
		dev_err(&pdev->dev, "failed to register subdev\n");
		goto error;
	}

	pr_info("initialization successfull.");

	return 0;

error:
	media_entity_cleanup(&subdev->entity);
	xvip_cleanup_resources(&xtpg->xvip);
	return ret;
}

static int xtpg_remove(struct platform_device *pdev)
{
	struct xtpg_device *xtpg = platform_get_drvdata(pdev);
	struct v4l2_subdev *subdev = &xtpg->xvip.subdev;

	v4l2_async_unregister_subdev(subdev);
	media_entity_cleanup(&subdev->entity);

	xvip_cleanup_resources(&xtpg->xvip);

	return 0;
}

static const struct of_device_id xtpg_of_id_table[] = {
	{ .compatible = "workswell,wsltpg" },
	{ }
};
MODULE_DEVICE_TABLE(of, xtpg_of_id_table);

static struct platform_driver xtpg_driver = {
	.driver = {
		.name		= "workswell-tpg",
		.of_match_table	= xtpg_of_id_table,
	},
	.probe			= xtpg_probe,
	.remove			= xtpg_remove,
};

module_platform_driver(xtpg_driver);

MODULE_AUTHOR("Laurent Pinchart <laurent.pinchart@ideasonboard.com>");
MODULE_DESCRIPTION("Xilinx Test Pattern Generator Driver");
MODULE_LICENSE("GPL v2");
